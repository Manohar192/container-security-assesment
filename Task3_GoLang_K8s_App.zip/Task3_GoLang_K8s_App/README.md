# Task 3 - GoLang App with Kubernetes Deployment

## 📌 Objective
Create a GoLang-based web app that shows the current date & time, containerize it with Docker, deploy it to Kubernetes with 2 replicas, and expose it over the internet.

---

## 🧰 Files Included

- `main.go`: Simple GoLang web server
- `Dockerfile`: For building the Docker image
- `deployment.yaml`: Kubernetes Deployment with 2 replicas
- `service.yaml`: Kubernetes Service to expose the app
- `README.md`: Documentation and steps

---

## ▶️ How to Run

### Step 1: Build Docker Image
```bash
docker build -t your-dockerhub-username/datetime-app .
docker push your-dockerhub-username/datetime-app
```

### Step 2: Deploy to Kubernetes
```bash
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
```

### Step 3: Access the App
- If using Minikube:
```bash
minikube service datetime-service
```
- If on cloud: Check External IP via `kubectl get svc`

---

## ✅ Author: Your Name
