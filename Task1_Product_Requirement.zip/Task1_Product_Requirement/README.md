# Task 1 - Container Vulnerability Scanner

This folder contains:
- `PRD_Task1.md`: Product Requirement Document
- Wireframe Descriptions
- Developer tasks

This project helps users scan Docker images and find critical security vulnerabilities using tools like Trivy or Clair. Ideal for DevOps and SRE teams.
