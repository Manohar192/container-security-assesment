# Task 1 - Container Image Vulnerability Scanner

## 🧩 Problem Overview:
Organizations manage thousands of container images that include applications, dependencies, and system libraries. These components may have known security vulnerabilities (CVEs). Users need an efficient way to:
- Identify vulnerable container images
- Understand severity levels (Critical/High/Medium/Low)
- Take action to fix vulnerabilities quickly

---

## 📄 Objective:
Design a user-friendly dashboard that displays container image vulnerabilities with filtering, sorting, and detailed CVE insights.

---

## ✏️ User Stories:
| ID    | User Story                                                                     |
| ----- | ------------------------------------------------------------------------------ |
| US-01 | As a user, I want to view all container images with their vulnerability status |
| US-02 | As a user, I want to filter images by severity level                           |
| US-03 | As a user, I want to search for images by name or tag                          |
| US-04 | As a user, I want to see detailed vulnerability reports per image              |
| US-05 | As a user, I want remediation steps for each vulnerability                     |

---

## 📊 Key Features:
- Image Scan Integration (e.g., Trivy, Clair)
- Dashboard View
- Severity Badges
- Search and Filter
- CVE Details Page with Fix Recommendations

---

## 📈 Success Metrics:
- % of critical vulnerabilities resolved within 24 hours
- Time from scan to fix
- Number of vulnerabilities identified per scan cycle

---

## 🖼️ Wireframe (Described):
**Dashboard Table**
```
| Image Name     | Status     | Vulnerabilities | View |
|----------------|------------|------------------|------|
| nginx:1.19     | ⚠️ High     | 5 CVEs          | 🔎   |
| mongo:4.4      | 🔥 Critical | 12 CVEs         | 🔎   |
```

**Image Detail Page**
```
| CVE ID        | Severity | Description        | Fix Instruction   |
|---------------|----------|--------------------|-------------------|
| CVE-2023-1234 | Critical | Buffer Overflow    | Update libXYZ     |
```

---

## ✅ Developer Tasks:
| Task                    | Description                            |
|-------------------------|----------------------------------------|
| Integrate Trivy scanner| Run image scans                        |
| Create dashboard UI     | Table with sorting/filter              |
| Build CVE detail page   | Shows vulnerabilities & solutions      |
| Design DB schema        | Store images, scan results, CVEs       |

---

## 📁 Folder Structure
```
Task1_Product_Requirement/
├── PRD_Task1.md
└── README.md
```
