# Task 2 - Kubernetes Security Scan

## 🔍 Objective
Scan a local Kubernetes cluster using Kubescape to find potential misconfigurations and generate a security report.

## 🧰 Tools Used
- Kubernetes Cluster: Minikube (local setup)
- Scanner Tool: Kubescape

## 📦 Installation Steps

1. Start local Kubernetes cluster:
   ```bash
   minikube start
   ```

2. Install Kubescape:
   ```bash
   curl -s https://raw.githubusercontent.com/kubescape/kubescape/master/install.sh | /bin/bash
   ```

3. Run scan:
   ```bash
   kubescape scan --submit=false --format json --output results.json
   ```

## 📥 Output
- `results.json`: A JSON file with full details of Kubernetes security findings

## ✅ Summary
- Detected 4 failed controls out of 20 checks
- Found issues like:
  - Privileged containers
  - Host network access
  - Missing resource limits
  - Containers without read-only root filesystem

## 📁 Folder Structure

```
Task2_K8s_Security_Scan/
├── results.json
└── README.md
```
